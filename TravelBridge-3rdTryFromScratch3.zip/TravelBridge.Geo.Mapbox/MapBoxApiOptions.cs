namespace TravelBridge.Geo.Mapbox;

public class MapBoxApiOptions
{
    public string ApiKey { get; set; } = string.Empty;
    public string BaseUrl { get; set; } = string.Empty;
}
