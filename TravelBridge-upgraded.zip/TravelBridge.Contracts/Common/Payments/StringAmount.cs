namespace TravelBridge.Contracts.Common.Payments
{
    public class StringAmount
    {
        public string Description { get; set; }
        public decimal Amount { get; set; }
    }
}
