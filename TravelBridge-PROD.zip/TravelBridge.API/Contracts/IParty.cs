namespace TravelBridge.API.Contracts
{
    public interface IParty
    {
        public string Party { get; set; }
    }
}