namespace TravelBridge.API.Models.DB
{
    public class BaseModel
    {
        public int Id { get; set; }
        public DateTime? DateCreated { get; set; }
    }
}
