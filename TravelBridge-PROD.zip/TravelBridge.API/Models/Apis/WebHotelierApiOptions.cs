﻿namespace TravelBridge.API.Models.Apis
{
    public class WebHotelierApiOptions
    {
        public string BaseUrl { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}