namespace TravelBridge.Contracts.Contracts.Responses
{
    public class DataSuccess
    {
        public string CheckIn { get; set; }
        public string CheckOut { get; set; }
        public int ReservationId { get; set; }
        public string HotelName { get; set; }
    }
}
