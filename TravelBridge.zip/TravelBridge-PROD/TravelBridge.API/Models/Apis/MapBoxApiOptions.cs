﻿namespace TravelBridge.API.Models.Apis
{
#pragma warning disable S2094 // Classes should not be empty
    public class MapBoxApiOptions : BaseApiOptions
#pragma warning restore S2094 // Classes should not be empty
    {
    }
}
