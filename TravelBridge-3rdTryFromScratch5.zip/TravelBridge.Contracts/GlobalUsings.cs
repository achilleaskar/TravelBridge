// Global using directives for TravelBridge.Contracts

global using System.Text.Json.Serialization;
global using TravelBridge.Contracts.Common;
global using TravelBridge.Contracts.Common.Board;
global using TravelBridge.Contracts.Helpers.Converters;