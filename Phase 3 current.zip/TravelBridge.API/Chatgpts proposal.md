I reviewed your `PHASE3_MODELS_SCHEMA.md` and it’s **very solid and implementation-ready**. 
Before you start coding, there are a handful of **small but important** tweaks I’d make to avoid future bugs / mismatches.

## ✅ What’s already great

* Clear separation: EF entities in API + provider uses a **store interface** (`IOwnedInventoryStore`) ✅ 
* Composite PK `(RoomTypeId, Date)` for nightly inventory ✅ 
* Pricing approach: `PricePerNight ?? BasePricePerNight` ✅ 
* RateId format `rt_{roomTypeId}-{adults}[_{children...}]` (compatible with your Phase 2 parsing fixes) ✅ 

---

## 🔧 Fix/clarify these before implementing

### 1) Define **date-range semantics** (inclusive vs exclusive) everywhere

Right now, admin requests use `StartDate/EndDate`, but you don’t define whether `EndDate` is inclusive. 

**Recommendation (standard + avoids off-by-one bugs):**

* For inventory queries and booking ranges: treat ranges as **`[start, end)`** (end **exclusive**), because check-out night is not consumed.
* For admin “set capacity/closed units”: accept `EndDateInclusive` **or** document that it’s exclusive too.

If you keep current names, just enforce:

* `UpdateInventoryCapacityAsync(roomTypeId, startDate, endDateExclusive, …)`
* same for closed units

### 2) `OwnedHotelStoreModel` is missing fields that exist in the entity

Your EF `OwnedHotel` includes `PostalCode`, but the store model doesn’t expose it. 
Either:

* add `PostalCode` to `OwnedHotelStoreModel`, **or**
* drop it from the entity for Phase 3

(Keep store model and entity aligned; otherwise you’ll keep re-touching later.)

### 3) EF Core + MySQL: `DateOnly` requires attention

`OwnedInventoryDaily.Date` is `DateOnly`. That’s fine, but **ensure your EF provider supports it** and you configure it cleanly. 

If you’re using Pomelo MySQL + EF Core 8/9, it usually works, but you may still want explicit column type:

* `Date` → `DATE`
* `LastModifiedUtc` → `DATETIME(6)`

### 4) Add `DefaultTotalUnits` to `OwnedRoomType` (optional, but super useful)

Your seed job needs a default `TotalUnits`. Right now it’s not on the model. 
Add:

* `DefaultTotalUnits INT` to `OwnedRoomType`

So seeding can create inventory rows with the correct capacity without hardcoding.

### 5) Validation constraints: don’t rely only on MySQL CHECK

You listed constraints like `ClosedUnits + HeldUnits + ConfirmedUnits <= TotalUnits`. Great. 
But in MySQL, CHECK enforcement depends on version/settings historically.

**Do both:**

* enforce in API validation (repository/admin endpoint)
* keep CHECK in schema/migration where supported (nice extra safety)

### 6) Availability “requested rooms” calculation is currently vague

You show:

````csharp
return party.RoomCount;
``` :contentReference[oaicite:10]{index=10}

But your Phase 2 world uses party items with `RoomsCount`. For Owned, you’ll almost certainly want:
- `requestedRooms = sum(partyItem.RoomsCount)` (or equivalent)

Otherwise you’ll undercount multi-room parties.

### 7) Index note: `(Latitude, Longitude)` helps, but it’s not a true geo index
You propose `IX_OwnedHotel_Location (Latitude, Longitude)` for bounding boxes. :contentReference[oaicite:11]{index=11}  
That’s fine for MVP, but long-term you may want:
- a `POINT` column + SPATIAL index (Phase 6+), or
- at least keep search using bounding box first, then haversine in memory.

---

## Small implementation recommendations (so Phase 3 stays clean)
- Mark computed property:
  - `AvailableUnits` as `[NotMapped]` (or fluent ignore) so EF doesn’t try to persist it. :contentReference[oaicite:12]{index=12}
- In `IOwnedInventoryStore`, the bulk inventory method is great:
  - `GetInventoryForMultipleRoomTypesAsync(...)` will matter for search performance. :contentReference[oaicite:13]{index=13}

---

## Verdict
✅ Your schema/doc is **valid** and matches the Phase 3 plan. :contentReference[oaicite:14]{index=14}  
If you only change a few things, make it these three:
1) **Define endDate as exclusive** everywhere (or rename for admin)
2) Align store models with entity fields (PostalCode mismatch)
3) Make sure requestedRooms = **sum RoomsCount**, not a single value

If you want, I can generate the **EF Core Fluent configs** for these entities (keys, indexes, column types, unique constraints) based exactly on your doc, so you can paste them into `OnModelCreating`.
````
