namespace TravelBridge.Geo.HereMaps;

public class HereMapsApiOptions
{
    public string ApiKey { get; set; } = string.Empty;
    public string BaseUrl { get; set; } = string.Empty;
}
