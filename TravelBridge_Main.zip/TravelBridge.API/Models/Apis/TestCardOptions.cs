namespace TravelBridge.API.Models.Apis;

public class TestCardOptions
{
    public string CardNumber { get; set; } = string.Empty;
    public string CardType { get; set; } = string.Empty;
    public string CardName { get; set; } = string.Empty;
    public string CardMonth { get; set; } = string.Empty;
    public string CardYear { get; set; } = string.Empty;
    public string CardCVV { get; set; } = string.Empty;
}
